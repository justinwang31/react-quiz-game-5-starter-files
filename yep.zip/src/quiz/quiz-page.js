import Game from "./game";

function QuizPage() {
  return (
    <main>
      <Game />
    </main>
  );
}

export default QuizPage;
