function HomePage() {
  return (
    <main>
      <h1>Home Page 🏠</h1>
      <p>This is the home page.</p>
    </main>
  );
}

export default HomePage;
